#include <stdio.h>

void dbf(void)
{
//fprintf(stderr,"\ndbf\n");
}
